<?php
	require_once("Sajax.php");

	function checkObject($obj1) {
		return $obj1;
	}

	$sajax_request_type = "POST";

	sajax_init();
	sajax_export("checkObject");
	sajax_handle_client_request();

?>
<html>
	<head>
		<script type="text/javascript" src="json.js"></script>
		<script>
	<?php
		sajax_show_javascript();
	?>

		function doCall() {
			var myObj = new Object();
			myObj.name = "wyatt";
			myObj.type = "boy";
			myObj.atest = new Array();
			for(var i = 0; i <= 5; i++) {
				myObj.atest[i] = i;
			}

			x_checkObject(myObj, cb_checkObj);

		}

		function doCall2() {
			var myString = "wyatt";
			x_checkObject(myString, cb_checkObj);
		}

		function cb_checkObj(jsObj) {
			if(jsObj.name && jsObj.type) {
				alert("name:" + jsObj.name + ",type:" + jsObj.type);
				for (var i = 0; i <= 5; i++) {
					console.log(jsObj.atest[i]);
				}
			} else {
				alert(jsObj);
			}
		}
		</script>
	</head>
	<body>
		Test Page
		<button onclick="doCall()" value="do call">Object Test</button>
		<button onclick="doCall2()" value="do call 2">Variable Test</button>
	</body>
</html>
